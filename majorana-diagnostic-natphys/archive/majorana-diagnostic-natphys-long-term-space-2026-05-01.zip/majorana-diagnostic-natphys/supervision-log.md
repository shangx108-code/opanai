# Supervision Log

## 2026-05-01 | Round 16 supervision after CMJJ panel triage

### Overall evaluation
This round did exactly what the project needed after the first source-data run: it separated "real numerical progress" from "final figure readiness." That is a healthy move. The CMJJ branch is no longer blocked by absence of data, but it is still bottlenecked by panel selectivity.

### Gap to target-journal standard
- Figures 2 and 3 are now close enough to treat as candidate manuscript assets.
- Figures 4 and 5 are still not sharp enough to carry the full false-positive-resistant claim without another numerical round.
- The project still needs one cleaner negative-control/transport consistency story before venue-level framing should rise further.

### Most critical quality risk
The current risk is now overpromoting the transport and negative-control panels simply because they exist. Existence is not enough; they still need to discriminate cleanly.

### Plan-revision advice
1. Keep Figures 2 and 3 on the "plot next" track.
2. Put Figures 4 and 5 on the "retune before plotting" track.
3. Frame the next coding round around one narrow objective: preserve misleading local near-zero structure in the controls while making the topology-plus-nonlocal failure more decisive.
4. Delay venue-language inflation until that specific upgrade is achieved.

### Newly completed items
- Added `cmjj-first-pass-panel-triage-2026-05-01.md`
- Updated `project-state.md` to reflect that Figures 4 and 5 are now the active bottleneck

## 2026-05-01 | Round 15 supervision after first CMJJ source-data run

### Overall evaluation
This round converted the compensated-magnetic branch from a planning object into a real numerical object. The project now has a reproducible first-pass Figures 2-5 source-data bundle for the CMJJ application, generated in the current runtime without waiting for missing plotting or scipy dependencies.

### Gap to target-journal standard
- The project now has real CMJJ data, but the package is still a first-pass minimal effective-model implementation rather than the final manuscript-grade model stack.
- The transport layer is usable as a reproducible proxy bundle, but it still needs a scientific judgment call on whether the current observable definitions are strong enough for the final paper.
- Plotting, panel selection, and caption discipline remain open; source data alone is not yet a finished figure package.

### Most critical quality risk
The next drift risk is subtler than before: the project could mistake "first real data exist" for "the figures are already final." They are not final yet; they are now real enough to critique and upgrade.

### Plan-revision advice
1. Freeze `generate_cmjj_source_data.py` and `cmjj_source_data_config.json` as the reproducible baseline.
2. Use the current CSV bundle to inspect which panels already support the intended story and which ones need stronger observable definitions or parameter retuning.
3. Only after that add rendered figures and manuscript-facing captions.
4. Keep the venue claim level tied to the strongest surviving panels, not to the full ambition of the original branch note.

### Newly completed items
- Added `code/generate_cmjj_source_data.py`
- Added `config/cmjj_source_data_config.json`
- Generated `data/cmjj-source-data-2026-05-01/manifest.json`
- Generated first-pass source-data CSV bundles for Figures 2-5 in the CMJJ branch

## 2026-05-01 | Round 14 supervision after compensated-magnetic intake lock

### Overall evaluation
This round produced a real project-state improvement even without new numerics. The project no longer treats the compensated-magnetic Josephson-junction idea and the NC repack path as loose prose floating in user files; both are now frozen as canonical long-term-space objects tied to the same Majorana diagnostic project.

### Gap to target-journal standard
- The compensated-magnetic branch is now clearly defined, but it still lacks a real figure-grade source-data package.
- The project now has an NC-safe claim stack, but it still lacks the reproducibility bundle that would make that venue path credible.
- The paper still does not have the compensated-magnetic Figures 2-5 outputs needed to replace narrative ambition with auditable evidence.

### Most critical quality risk
The project could still confuse "better framing" with "submission progress" if it does not now move immediately into a compensated-magnetic evidence sprint.

### Plan-revision advice
1. Treat `A-compensated-magnetic-cmjj-blueprint-2026-05-01.md` as the fixed application brief for the next coding round.
2. Treat `B-nc-repositioning-and-reproducibility-plan-2026-05-01.md` as the fixed packaging brief for manuscript and archive work.
3. Make the next execution round produce real source data for bulk topology, open-boundary ambiguity, nonlocal transport, and at least ABS plus impurity/disorder controls in the compensated-magnetic setting.
4. Keep all venue-language upgrades blocked until that figure bundle exists with scripts and parameter records.

### Newly completed items
- Corrected `memory/CURRENT-PROJECT-SPACE.md` to point to `majorana-diagnostic-natphys`
- Added `A-compensated-magnetic-cmjj-blueprint-2026-05-01.md`
- Added `B-nc-repositioning-and-reproducibility-plan-2026-05-01.md`
- Updated `project-state.md` and `archive-checklist.md` to reflect the new application and packaging lock

## 2026-04-24 | Round 1 initialization

### Overall evaluation
The project is scientifically promising but still below Nature Physics threshold. The uploaded note has strong taste in problem choice and methodology, yet it reads more like a high-level research program than a finished venue-calibrated paper plan.

### Gap to target-journal standard
- The manuscript concept does not yet show a sufficiently sharp advance over existing Majorana-diagnostic literature.
- The planned evidence chain is broad, but not yet prioritized into one decisive main-text story.
- Several suggested references in the note are not verified and should not be used until checked.

### Most critical quality risk
The paper may be read as an incremental synthesis of known ideas:
- nonlocal conductance matters;
- disorder creates false positives;
- local zero-bias peaks are insufficient.

### Plan-revision advice
1. Replace the vague "unified protocol" language with one falsifiable centerpiece.
2. Restrict the main text to the minimal decisive triad: local failure, nonlocal/topological rescue, cross-platform stress test.
3. Push noise and other auxiliary probes to a stretch goal unless they create a clear new physical principle.
4. Verify every citation before using it in manuscript positioning.

### Items that already meet baseline
- Problem importance
- Relevance to condensed-matter and quantum-device audiences
- Suitable computational formalism

### Items still below submission bar
- Novelty differentiation
- Evidence completeness
- Figure-ready proof structure
- Clean reference ledger

## 2026-04-25 | Round 2 supervision after literature check

### Overall evaluation
The project is healthier and more disciplined than yesterday because the manuscript has been repositioned around a sharper field-level question. It is now easier to imagine a high-impact paper, but the work is still pre-submission.

### Gap to target-journal standard
- The manuscript now has a better central sentence, but not yet a theorem-like or protocol-like result with completed evidence.
- The compensated-magnetic application is timely, but no longer enough by itself to carry the novelty burden.
- A toy-model calculation exists, yet it serves only as an internal honesty check and not as publishable evidence.

### Most critical quality risk
The paper could still drift into a polished but under-supported conceptual essay if the full benchmark is not completed.

### Plan-revision advice
1. Treat the compensated-magnetic platform as the motivating application, not the sole novelty anchor.
2. Make the first real figure a failure figure for local zero-bias peaks.
3. Do not claim a robust topological window until the final transport code and topology label agree.
4. Keep all unverified 2026 references out of the manuscript unless checked from a primary source.

### Newly completed items
- Verified the 2026 TAJJ overlap from a primary source
- Produced a manuscript package and a LaTeX-ready draft
- Generated a first-pass toy-model stress-test figure

## 2026-04-26 | Round 3 supervision after success-criteria escalation

### Overall evaluation
The project standard is now substantially stricter in a healthy way. The work is no longer allowed to drift toward a soft "promising draft" definition of success. The new explicit requirement is an estimated acceptance probability above 70% together with a closed evidence checklist.

### Gap to target-journal standard
- The manuscript still lacks the first real Level 3 evidence milestone: a positive-control/false-positive benchmark from one common transport code path.
- The theory logic is now much better defined internally, but it is not yet integrated into the manuscript as derivation-grade text.
- No main-text data figure yet meets the new real-data-only rule.

### Most critical quality risk
The project could continue producing articulate internal documents without quickly enough converting them into real benchmark data.

### Plan-revision advice
1. Treat the new theory note as frozen guidance and stop re-litigating the observable hierarchy unless a benchmark result forces a change.
2. Spend the next coding round on the Rashba positive control and one false-positive control in a shared pipeline.
3. Do not generate any synthetic data illustrations for the manuscript; restrict image generation to conceptual schematics only.
4. Do not raise the acceptance estimate meaningfully until Level 3 evidence exists.

### Newly completed items
- Raised the completion bar to >70% estimated acceptance probability plus closed evidence checklist
- Added a formal diagnostic-hierarchy theory note
- Upgraded the automation cadence to every 2 hours

## 2026-04-26 | Round 4 supervision after first real-data benchmark

### Overall evaluation
This is the first iteration that clearly moves the project from planning into auditable computation. The benchmark is still preliminary, but it is already scientifically informative because it exposes a weakness in any attempt to collapse the diagnosis onto a single nonlocality score.

### Gap to target-journal standard
- The benchmark currently uses finite-chain spectral proxies rather than the final transport-and-topology bundle.
- The false-positive control is only one member of the required control family.
- The current figure is internal-quality only and not yet publication-grade in either visual design or observable completeness.

### Most critical quality risk
The team could prematurely interpret the current nonlocality score as near-sufficient, even though the first benchmark already shows that it is not.

### Plan-revision advice
1. Preserve the current benchmark as a cautionary internal figure, not as a final manuscript figure.
2. Make the next coding round about attaching lead self-energies and computing transport rather than adding more spectral-only scans.
3. Keep the smooth-dot control in the benchmark suite because it is already proving useful.
4. Let the first main-text failure figure show not only that local peaks fail, but also that naive nonlocality-only metrics can mislead.

### Newly completed items
- Built a shared finite-chain Rashba benchmark for a positive control and a smooth-dot false-positive control
- Stored real CSV outputs and a summary image derived from the computed data

## 2026-04-27 | Round 5 supervision after expanded transport numerics

### Overall evaluation
The project now has a much broader numerical base than before. This is real progress: the missing result categories are being closed one by one rather than left as placeholders. At the same time, the new results reinforce that numerical completeness and scientific sharpness are not the same thing.

### Gap to target-journal standard
- The transport bundle exists, but the failure-figure logic is still not sharp enough because the current false-positive controls do not yet produce the strongest misleading zero-bias behavior.
- The topology layer still needs a more decisive implementation.
- The positive-control result remains more useful as a pipeline anchor than as a polished Nature Physics figure.

### Most critical quality risk
The team could mistake broader output coverage for a solved evidence problem, even though the hardest discriminating case is still under-tuned.

### Plan-revision advice
1. Keep the new transport bundle as a milestone, but do not present it as final proof.
2. The next numerical round should target parameter tuning for the strongest false-positive cases, especially dot-induced and impurity-driven near-zero states.
3. After that, replace the topology proxy with a more decisive implementation or a cleaner benchmark construction.
4. Only then should the manuscript-facing figure set be rebuilt.

### Newly completed items
- Added a shared transport benchmark script and stored CSV outputs for positive-control, smooth-dot, impurity, disorder, eta-broadening, and bias-trace scans

## 2026-04-27 | Round 6 supervision after three-terminal rebuild

### Overall evaluation
This is a meaningful step forward. The project now has a three-terminal benchmark and actual Figure 3/4 candidates built from real data rather than placeholders. That substantially improves manuscript credibility.

### Gap to target-journal standard
- The positive-control topology story is still not visually decisive enough in the current finite-size paneling.
- The false-positive suite is stronger than before, but disorder still overwhelms the comparison.
- The inhomogeneous topology layer still needs a more defensible discriminator than the present clean-backbone criterion.

### Most critical quality risk
The paper could now look visually complete before the topological logic is truly complete.

### Plan-revision advice
1. Keep the new Figure 3/4 as working candidates, not final camera-ready figures.
2. The next numerical round should focus on strengthening the topological layer and rebalancing the disorder-versus-dot/impurity comparison.
3. After that, refresh the captions and main-text interpretation so the figures tell the right story without overclaiming.

### Newly completed items
- Added a three-terminal benchmark script
- Rebuilt Figure 3 and Figure 4 candidates from real three-terminal data

## 2026-04-27 | Round 7 supervision after topology-layer triage

### Overall evaluation
The project bottleneck is now narrower and more actionable than before. The main risk is no longer "missing figures" in a generic sense; it is specifically that the current Figure 4 topology panel cannot yet carry a Nature Physics-grade conclusion because it is not computed on the same inhomogeneous landscape as the misleading false positives.

### Gap to target-journal standard
- The paper still lacks a manuscript-defensible inhomogeneous topological discriminator.
- The current figure logic risks looking more complete than it really is.
- The next numerical round is not free to explore broadly; it must be tied to one auditable Figure 4 rebuild criterion.

### Most critical quality risk
The team could polish captions and prose around the present Figure 4 and accidentally turn a working benchmark into an overstated result.

### Plan-revision advice
1. Replace the clean-backbone criterion with one full-device class-D invariant in the shared three-terminal pipeline.
2. Define the next rebuild around `nu_ring` and `P_topo`, not around additional ad hoc nonlocal scores.
3. Only refresh the Figure 4 caption and Results paragraph after the full-device rerun exists.
4. Keep the disorder family visually present, but rebalance the operating points so dot and impurity false positives remain scientifically visible.

### Newly completed items
- Froze a topology-layer upgrade specification in `topology-layer-upgrade-spec-2026-04-27.md`
- Added directly reusable manuscript paragraph and caption language for the future full-device topology rebuild
- Identified the current scheduled-run blocker: the workspace does not contain the benchmark scripts or output bundles needed for a rerun

## 2026-04-27 | Round 8 supervision after manuscript-facing Figure 4 rewrite lock

### Overall evaluation
This round did not improve the evidence base, but it did improve manuscript discipline. That matters because the project had reached the point where better-looking prose could easily outrun the data. The paper is now less likely to overclaim before the full-device topology rerun is completed.

### Gap to target-journal standard
- The decisive full-device topology rerun is still missing.
- Figure 4 remains a working figure until `nu_ring` and `P_topo` are computed on the same inhomogeneous instances as the transport observables.
- The manuscript still cannot claim that topology has been established from the current benchmark package.

### Most critical quality risk
The main risk is now rhetorical inflation: the figure logic is sharp enough to sound finished even though the core topology evidence is not yet closed.

### Plan-revision advice
1. Use the new rewrite pack as a holding structure, not as permission to finalize the Results section.
2. Treat every sentence in Figure 4 as conditional on the missing full-device rerun unless it refers only to the current working benchmark.
3. Make the next executable round purely about implementing `nu_ring` and regenerating the operating-point table.
4. Refresh captions only after the rerun outputs exist in the same workspace as the manuscript files.

### Newly completed items
- Produced a directly reusable Figure 4 rewrite pack in `figure4-full-device-topology-rewrite-v1.md`
- Recorded the scheduled-run environment as a hard blocker for numerical execution rather than silently treating it as a soft delay

## 2026-04-29 | Round 9 supervision after strengthened recovery-mode restart

### Overall evaluation
This round still does not improve the evidence base, but it does materially improve reproducibility control. The project is no longer pretending that the three-terminal bundle is simply "somewhere"; the current workspace now contains an explicit provenance reconstruction and a precise missing-file list for the historical benchmark package.

### Gap to target-journal standard
- The executable three-terminal script path is still absent from the current workspace.
- The historical CSV and PNG outputs for the benchmark bundle are still absent from the current workspace.
- The full-device topology rerun with `nu_ring` and `P_topo` therefore remains blocked even though its specification is now stable and locally linked to the missing asset list.

### Most critical quality risk
The project could confuse provenance recovery with evidence recovery and start writing as though the bundle had been numerically rebuilt.

### Plan-revision advice
1. Treat the recovered manifest as a recovery control document, not as scientific output.
2. Make the next executable round about restoring the shared three-terminal script and inputs from persistent storage.
3. Only after that restoration should the project resume the `nu_ring` and `P_topo` rerun.
4. Keep all Figure 4 manuscript language conditional until the real rerun outputs reappear.

### Newly completed items
- Recreated `/workspace/output/three-terminal-benchmark/RECOVERY_MANIFEST.md`
- Recreated `/workspace/output/three-terminal-benchmark/provenance_manifest.json`
- Converted the missing-bundle state into an explicit, auditable blocker with an exact expected-file list

## 2026-04-29 | Round 10 supervision after runnable recovery-bootstrap setup

### Overall evaluation
This round still does not restore scientific evidence, but it materially improves execution readiness. The project now has a real recovery bootstrap that can be rerun in an empty scheduled workspace and will deterministically rebuild the recovery folder, inspect the live Python stack, and restate the exact missing benchmark assets without relying on conversational memory.

### Gap to target-journal standard
- The shared three-terminal benchmark entry script is still absent from the current workspace.
- All nine expected three-terminal benchmark assets remain absent from the current workspace.
- The scheduled-run Python stack is incomplete for a likely rerun path because `scipy` and `matplotlib` are not currently importable.

### Most critical quality risk
The project could continue assuming that "restoring the old bundle" is one blocker, when in fact the runnable environment itself has drifted enough that the eventual bundle restoration may still fail on import before any data are recomputed.

### Plan-revision advice
1. Keep the recovery bootstrap as the required first command in future scheduled runs until the real script bundle is restored.
2. Make the next execution round about recovering `three_terminal_benchmark.py` and the historical CSV inputs or outputs from persistent storage, not about manuscript work.
3. Immediately after script restoration, close the missing `scipy` and `matplotlib` dependencies before attempting the `nu_ring` and `P_topo` rerun.
4. Continue treating all figure and manuscript language as conditional until the benchmark files are regenerated from a live runnable path.

### Newly completed items
- Added `memory/majorana-diagnostic-natphys/code/majorana_recovery_bootstrap.py`
- Regenerated `/workspace/output/three-terminal-benchmark/RECOVERY_MANIFEST.md`
- Generated `/workspace/output/three-terminal-benchmark/environment_audit.json`
- Generated `/workspace/output/three-terminal-benchmark/missing_assets.json`

## 2026-04-29 | Round 11 supervision after persistent-storage recovery search

### Overall evaluation
This round still does not restore scientific evidence, but it sharpens the recovery state into a true upstream blocker. The project now knows that the three-terminal bundle is not merely missing from the immediate workspace path: the live workspace/container search and connected Google Drive metadata search both failed to recover the shared script or any historical bundle assets, while the recovery provenance was successfully regenerated again in the current workspace.

### Gap to target-journal standard
- The shared three-terminal benchmark entry script is still absent from every searched local recovery path.
- All nine expected benchmark CSV/PNG assets remain absent from the current workspace.
- The scheduled-run Python stack still lacks `scipy` and `matplotlib`, so even a restored script would not yet rerun cleanly in the present environment.

### Most critical quality risk
The project could waste more rounds treating the blocker as a manuscript problem or a vague archive problem when it is now specifically a missing persistent-source recovery problem for the three-terminal rerun path.

### Plan-revision advice
1. Keep the regenerated recovery bundle as the canonical proof of absence in the current workspace, not as a substitute for data.
2. Make the next execution round about recovering `three_terminal_benchmark.py` and the nine expected bundle files from a persistent source outside the currently mounted workspace or searchable Drive index.
3. Immediately after script recovery, restore `scipy` and `matplotlib` before attempting the `nu_ring`/`P_topo` rerun.
4. Continue blocking manuscript-final language until the live rerun path exists again.

### Newly completed items
- Re-ran `majorana_recovery_bootstrap.py` and regenerated the recovery provenance files in `/workspace/output/three-terminal-benchmark/`
- Confirmed by broader local/container search that no recoverable three-terminal script or bundle assets exist in the mounted workspace
- Confirmed by connected Google Drive metadata search that no directly searchable archived copy of the missing three-terminal bundle is currently exposed there

## 2026-04-29 | Round 12 supervision after direct environment-recovery attempt

### Overall evaluation
This round still does not restore benchmark data, but it turns the environment question into a concrete upstream blocker instead of a vague missing-package note. The project now knows that a normal online dependency-repair path is not currently available from this scheduled container.

### Gap to target-journal standard
- The shared three-terminal benchmark entry script is still absent from the current workspace.
- All nine expected three-terminal benchmark assets remain absent from the current workspace.
- The scheduled-run Python stack still lacks `scipy` and `matplotlib`, and a direct `pip install` attempt failed because the configured package-index proxy returned `403 Forbidden`.

### Most critical quality risk
The project could waste additional rounds retrying the same online install path instead of switching to an offline wheel, prebuilt environment, or recovered script bundle that already carries its own executable stack assumptions.

### Plan-revision advice
1. Keep the recovery bootstrap as the first command in future scheduled runs.
2. Make the next execution round about recovering the shared three-terminal script and bundle from persistent storage together with an offline or prebundled dependency path.
3. Do not spend another round retrying a plain online `pip install` from this container unless the proxy or package source has actually changed.
4. Continue blocking manuscript-final language until the live rerun path and its dependencies both exist in the same workspace.

### Newly completed items
- Re-ran `majorana_recovery_bootstrap.py` and refreshed the environment audit in `/workspace/output/three-terminal-benchmark/`
- Attempted direct dependency restoration with `python -m pip install scipy matplotlib`
- Verified that the scheduled container cannot currently reach the configured package-index proxy for those installs

## 2026-04-29 | Round 13 supervision after targeted archive recovery retry

### Overall evaluation
This round still does not restore scientific evidence, but it does strengthen the recovery diagnosis into one narrower and more actionable statement. The project refreshed the three-terminal recovery provenance again and then rechecked connected project storage with focused archive queries rather than relying only on older broad-search notes.

### Gap to target-journal standard
- The shared three-terminal benchmark entry script is still absent from the live workspace.
- All nine expected three-terminal benchmark CSV/PNG assets remain absent from the live workspace after a fresh recovery-bootstrap run.
- A targeted connected-Google-Drive search for `majorana three terminal benchmark` and `majorana three terminal figures` returned no recoverable archive result.

### Most critical quality risk
The project could still waste a round searching the same indexed locations again, even though the current evidence now points more specifically to a non-mounted or otherwise non-indexed persistent source as the missing recovery location.

### Plan-revision advice
1. Keep `majorana_recovery_bootstrap.py` as the first command in future recovery runs.
2. Treat the canonical next action as restoring the three-terminal script bundle from non-mounted persistent storage rather than repeating the same workspace or indexed-Drive queries.
3. Pair any recovered script or asset bundle with an offline or prebundled `scipy`/`matplotlib` path before attempting the matched `nu_ring`/`P_topo` rerun.
4. Continue blocking any manuscript-final interpretation until the live rerun path and its data bundle are restored together.

### Newly completed items
- Re-ran `majorana_recovery_bootstrap.py` and reconfirmed `Missing assets: 9` with `Ready for topology rerun: False`
- Repeated targeted connected-Google-Drive archive searches for the missing three-terminal bundle using benchmark-specific queries
- Verified that the indexed archive path still does not expose a recoverable copy of the missing script or bundle
